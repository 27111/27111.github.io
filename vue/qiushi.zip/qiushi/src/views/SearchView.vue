<template>
  <div>
    searchview
  </div>
</template>

<script setup>
// import { RouterLink, RouterView, onBeforeRouteLeave } from 'vue-router';
// onBeforeRouteLeave((to, from) => {
//   console.log("from:" + from);
//   console.log("to:" + to.path);
// });
</script>

<style lang="less" scoped>

</style>